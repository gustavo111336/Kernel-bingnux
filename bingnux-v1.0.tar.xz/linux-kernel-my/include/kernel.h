#ifndef KERNEL_H
#define KERNEL_H

/* 1. Definições de Tipos (Portabilidade) */
// Isso garante que um 'uint32' tenha sempre 32 bits, essencial para kernel
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;

/* 2. Endereços de Hardware (QEMU Virt ARM) */
// No QEMU -M virt, a UART (console serial) fica neste endereço de memória
#define UART0_DR *((volatile uint32_t *)(0x09000000))

/* 3. Protótipos de Funções do Kernel */

// Funções de Saída (Console)
void uart_putc(char c);            // Envia um caractere
void kernel_print(char *str);      // Envia uma string inteira
void kernel_main(void);            // A função principal

// Funções de Gerenciamento de Sistema
void delay(uint32_t count);        // Um delay simples

#endif /* KERNEL_H */
