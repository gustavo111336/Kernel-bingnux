#define UART0_DR ((volatile unsigned int *)0x09000000)
#define UART0_FR ((volatile unsigned int *)(0x09000000 + 0x18))

void main() {
    // Loop infinito de teste
    while (1) {
        // Tenta escrever 'B' direto, ignorando o status por um momento
        *UART0_DR = 'B';
        
        // Pequeno delay manual (já que não temos sleep)
        for (volatile int i = 0; i < 1000000; i++);
    }
}

